package in.mindcraft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
